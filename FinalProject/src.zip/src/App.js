import './App.css';
import React from "react";
import {useState} from "react";
import Axios from 'axios';


function App() {
    const [table, setTable] = useState([]);

    const getTable = () => {
        Axios.get("http://localhost:5000/Data").then((response) =>{
            setTable(response.data)
            console.log(response.data)
        });
    }

    return (
        <div className="App">
            <div className="content">
                <h1>Hello World</h1>
                <hr/>
                <button onClick={getTable}>Show Table</button>
                <div className="mySQL">
                    <table>
                        <tr>
                            <th>Empl Id</th>
                            <th>First Name</th>
                            <th>Last name</th>
                            <th>Phone Number</th>
                            <th>Age</th>
                        </tr>
                        {table.map((row, key) => {
                            return <tr>
                              <td>{row.emplId}</td>
                              <td>{row.firstName}</td>
                              <td>{row.lastName}</td>
                              <td>{row.phoneNum}</td>
                              <td>{row.age}</td>
                            </tr>
                        })}
                    </table>
                </div>
            </div>
        </div>
    );
}

// class Data extends React.Component {
//     constructor(props) {
//         super(props);
//         this.state = getData();
//     }
//
//     render() {
//
//         const tableRow = this.state.map((row) =>
//             <tr>
//                 <td>{row.emplId}</td>
//                 <td>{row.firstName}</td>
//                 <td>{row.lastName}</td>
//                 <td>{row.phoneNum}</td>
//                 <td>{row.age}</td>
//             </tr>
//         );
//         return (
//             <table>{tableRow}</table>
//         )
//     }
// }


export default App;
